# Email Notification

## Description
This plugin makes the system send a notification when a new item or collection is added